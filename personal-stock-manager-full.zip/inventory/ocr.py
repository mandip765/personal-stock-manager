import pytesseract,cv2,re
def read_bill(path):
    img=cv2.imread(path)
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    text=pytesseract.image_to_string(gray)
    results=[]
    for line in text.splitlines():
        line=line.lower().strip()
        m=re.search(r'([a-z\s]+)[\-–]\s*(\d+)\s*(kg|ctn|pcs)',line)
        if m:
            results.append({'name':m.group(1).strip(),'qty':int(m.group(2)),'unit':m.group(3)})
    return results
